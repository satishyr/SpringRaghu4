package com.app.service;

import com.app.model.User;

public interface IUserService {

	Integer saveUser(User user);
}

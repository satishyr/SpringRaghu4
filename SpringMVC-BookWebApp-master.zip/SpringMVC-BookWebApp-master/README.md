# SpringMVC-BookWebApp
This application created using Spring MVC Spring JDBC and Maven to perform basic insert and retrieve operations

#Install Ojdbc14.jar into Maven Local repository using below command
mvn install:install-file -Dfile=ojdbc14.jar -DgroupId=com.oracle -DartifactId=oracle14 -Dversion=1.1.1 -Dpackaging=jar

#Change database details in AppConfig.java file
